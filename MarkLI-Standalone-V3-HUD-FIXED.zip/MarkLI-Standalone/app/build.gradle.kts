plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.markli.mobile"; compileSdk = 35
    defaultConfig { applicationId = "com.markli.mobile"; minSdk = 26; targetSdk = 35; versionCode = 3; versionName = "3.0" }
}

kotlin { jvmToolchain(17) }

dependencies { implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.appcompat:appcompat:1.7.0"); implementation("androidx.activity:activity-ktx:1.10.0"); implementation("com.squareup.okhttp3:okhttp:4.12.0") }
