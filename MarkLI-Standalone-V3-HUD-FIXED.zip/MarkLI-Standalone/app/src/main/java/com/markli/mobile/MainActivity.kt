package com.markli.mobile

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private val micCode = 42
    private var language = "hi"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        language = getPreferences(0).getString("language", "hi") ?: "hi"
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) applyTtsLanguage() }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread { request.grant(request.resources) }
                }
            }
            addJavascriptInterface(Bridge(), "AndroidMARK")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/app.html")
    }

    private inner class Bridge {
        @JavascriptInterface fun setApiKey(key: String) = getPreferences(0).edit().putString("gemini_key", key).apply()
        @JavascriptInterface fun getApiKey(): String = getPreferences(0).getString("gemini_key", "") ?: ""

        @JavascriptInterface fun setLanguage(value: String) {
            language = if (value.equals("en", true)) "en" else "hi"
            getPreferences(0).edit().putString("language", language).apply()
            runOnUiThread { applyTtsLanguage() }
        }

        @JavascriptInterface fun getLanguage(): String = language

        @JavascriptInterface fun requestMic() {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.RECORD_AUDIO), micCode)
            } else startListening()
        }

        @JavascriptInterface fun speak(text: String) {
            runOnUiThread { tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "MARK") }
        }

        @JavascriptInterface fun phoneCommand(command: String): Boolean = executePhoneCommand(command)

        @JavascriptInterface fun openApp(packageName: String): Boolean {
            val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            return true
        }

        @JavascriptInterface fun generate(prompt: String) {
            val key = getApiKey()
            if (key.isBlank()) { result("", "NO_API_KEY"); return }
            val languageInstruction = if (language == "hi") {
                "Reply primarily in natural Hindi (Devanagari). You may keep app names, technical terms, URLs, and commands in English when that is clearer."
            } else {
                "Reply in natural English."
            }
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "You are MARK, a helpful Android phone assistant. $languageInstruction Answer concisely and clearly. If the user asks for a phone action, describe the action clearly; the app may execute supported actions. User: $prompt")))))
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key")
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            OkHttpClient().newCall(req).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) { result("", e.message ?: "Network error") }
                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        val raw = it.body?.string() ?: ""
                        try {
                            val obj = JSONObject(raw)
                            val text = obj.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                            result(text, "")
                        } catch (_: Exception) { result("", "API error: ${it.code}") }
                    }
                }
            })
        }
        private fun result(text: String, err: String) = web.post { web.evaluateJavascript("window.androidResult && window.androidResult(${JSONObject.quote(text)}, ${JSONObject.quote(err)})", null) }
    }

    private fun executePhoneCommand(raw: String): Boolean {
        val c = raw.lowercase(Locale.ROOT).trim()
        return try {
            when {
                c.contains("turn off flashlight") || c.contains("torch off") || c.contains("flashlight off") || c.contains("फ्लैशलाइट बंद") || c.contains("टॉर्च बंद") -> toggleFlashlight(false)
                c.contains("flashlight") || c.contains("torch") || c.contains("फ्लैशलाइट") || c.contains("टॉर्च") -> toggleFlashlight(true)
                c.contains("wifi") || c.contains("wi-fi") || c.contains("वाईफाई") || c.contains("वाई-फाई") -> startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)).let { true }
                c.contains("bluetooth") || c.contains("ब्लूटूथ") -> startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)).let { true }
                c.contains("settings") || c.contains("setting") || c.contains("सेटिंग") -> startActivity(Intent(Settings.ACTION_SETTINGS)).let { true }
                c.contains("camera") || c.contains("कैमरा") -> startActivity(Intent("android.media.action.IMAGE_CAPTURE")).let { true }
                c.contains("youtube") || c.contains("यूट्यूब") -> launchFirst(arrayOf("com.google.android.youtube"))
                c.contains("whatsapp") || c.contains("व्हाट्सऐप") || c.contains("व्हाट्सएप") -> launchFirst(arrayOf("com.whatsapp", "com.whatsapp.w4b"))
                c.contains("maps") || c.contains("google map") || c.contains("मैप्स") || c.contains("गूगल मैप") -> launchFirst(arrayOf("com.google.android.apps.maps"))
                c.contains("chrome") || c.contains("browser") || c.contains("क्रोम") -> launchFirst(arrayOf("com.android.chrome", "com.google.android.apps.chrome"))
                c.contains("calculator") || c.contains("कैलकुलेटर") -> launchFirst(arrayOf("com.google.android.calculator", "com.android.calculator2"))
                c.startsWith("call ") || c.contains(" call ") || c.contains("कॉल ") -> dial(extractPhone(raw))
                c.startsWith("message ") || c.contains(" sms") || c.contains("text ") || c.contains("मैसेज") || c.contains("संदेश") -> composeMessage(raw)
                c.contains("alarm") || c.contains("अलार्म") -> startActivity(Intent(AlarmClock.ACTION_SET_ALARM).apply { putExtra(AlarmClock.EXTRA_MESSAGE, if (language == "hi") "MARK अलार्म" else "MARK alarm") }).let { true }
                c.contains("timer") || c.contains("टाइमर") -> startActivity(Intent(AlarmClock.ACTION_SET_TIMER).apply { putExtra(AlarmClock.EXTRA_LENGTH, 60); putExtra(AlarmClock.EXTRA_MESSAGE, if (language == "hi") "MARK टाइमर" else "MARK timer") }).let { true }
                else -> false
            }
        } catch (_: Exception) { false }
    }

    private fun launchFirst(pkgs: Array<String>): Boolean {
        for (p in pkgs) packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it); return true }
        return false
    }

    private fun extractPhone(raw: String): String = Regex("[+]?\\d[\\d ()-]{5,}").find(raw)?.value?.filter { it.isDigit() || it == '+' } ?: ""
    private fun dial(number: String): Boolean { if (number.isBlank()) return false; startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))); return true }

    private fun composeMessage(raw: String): Boolean {
        val i = Intent(Intent.ACTION_SENDTO).apply { data = Uri.parse("smsto:"); putExtra("sms_body", raw) }
        startActivity(i); return true
    }

    private fun toggleFlashlight(on: Boolean): Boolean {
        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return false
        cm.setTorchMode(id, on); return true
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("Speech recognition is unavailable on this phone"); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { js("window.voiceState&&window.voiceState('listening')") }
            override fun onBeginningOfSpeech() { js("window.voiceState&&window.voiceState('speaking')") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                js("window.voiceResult&&window.voiceResult(${JSONObject.quote(text)})")
                recognizer?.destroy(); recognizer = null
            }
            override fun onError(error: Int) { js("window.voiceState&&window.voiceState('error')"); recognizer?.destroy(); recognizer = null }
            override fun onEndOfSpeech() { js("window.voiceState&&window.voiceState('processing')") }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (language == "hi") "hi-IN" else "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        })
    }

    private fun applyTtsLanguage() {
        val locale = if (language == "hi") Locale("hi", "IN") else Locale("en", "IN")
        val result = tts.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.language = Locale.getDefault()
        }
    }

    private fun js(s: String) = web.post { web.evaluateJavascript(s, null) }
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == micCode && results.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
        else toast("Microphone permission is required for voice")
    }

    override fun onDestroy() {
        recognizer?.destroy(); tts.stop(); tts.shutdown(); super.onDestroy()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
