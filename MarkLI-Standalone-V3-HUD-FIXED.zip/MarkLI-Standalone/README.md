# MarkLI Standalone V3

Standalone Android MARK assistant. The phone does not depend on a PC/JARVIS server.

## Included
- Gemini `generateContent` integration through OkHttp
- Gemini API key setup from the phone
- Hindi-first voice recognition (`hi-IN`)
- Hindi Text-to-Speech (`hi-IN`)
- English language option
- Hindi/Hinglish phone command matching
- YouTube, WhatsApp, Maps, Chrome, Calculator launchers
- Wi-Fi, Bluetooth, Settings, Camera
- Flashlight on/off
- Dialer, SMS composer, alarms and timers
- Local WebView HUD UI
- Gradle wrapper configuration and Windows/Unix launcher scripts

## Build in VS Code
From the project root:

```powershell
.\gradlew.bat assembleDebug
```

If PowerShell says `gradlew.bat` is not recognized, make sure the terminal is opened in the folder containing `gradlew.bat`:

```powershell
cd "C:\path\to\MarkLI-Standalone-V3"
dir gradlew*
```

This package includes the wrapper configuration, but the Gradle bootstrap JAR could not be embedded in the generated archive in this environment. If `gradlew.bat` reports that Gradle is not installed, install Gradle 8.9+ or open/import the project in Android Studio once and then build from VS Code.

## Gemini API key
Open the app and tap **SETUP**. Enter your Gemini API key. The key is stored in the app's private preferences on the phone. Do not publish the APK with a personal API key embedded in source code.

## Hindi
Hindi is the default language. Use the language selector in the header to switch between **हिंदी** and **English**.

Examples:
- `यूट्यूब खोलो`
- `कैमरा खोलो`
- `फ्लैशलाइट चालू करो`
- `फ्लैशलाइट बंद करो`
- `वाईफाई खोलो`
- `व्हाट्सऐप खोलो`
- `सेटिंग खोलो`
- `कॉल 9876543210`

Android permissions and platform security are respected; the app cannot bypass Android restrictions.

## V3 HUD update
The Android app now uses a closer reproduction of the original MARK LI desktop HUD layout: 148px system-monitor rail, animated multi-ring central HUD with scan arcs/crosshair/ticks, central MARK face treatment, activity log, file-upload panel, command controls, status badges, and the original compact 54px header / 22px footer proportions.
