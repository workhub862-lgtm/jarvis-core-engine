@echo off
setlocal
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo.
echo Gradle is not installed or not available on PATH.
echo This project includes the Gradle Wrapper configuration, but the wrapper bootstrap JAR could not be bundled in this environment.
echo Install Gradle 8.9+ or open the project in Android Studio once, then run this command again.
echo.
exit /b 1
